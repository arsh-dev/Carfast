<?php

$api_key_id='rzp_live_eNNBvvlfttRJCm';

?>