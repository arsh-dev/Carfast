<?php
   define('DB_SERVER', 'localhost');
   define('DB_USERNAME', 'ars');
   define('DB_PASSWORD', '1234');
   define('DB_DATABASE', 'sajal');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>
